module.exports = require('./flatten');
