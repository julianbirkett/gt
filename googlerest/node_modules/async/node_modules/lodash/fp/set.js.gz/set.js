var convert = require('./convert'),
    func = convert('set', require('../set'));

func.placeholder = require('./placeholder');
module.exports = func;
