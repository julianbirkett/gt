var convert = require('./convert'),
    func = convert('isWeakSet', require('../isWeakSet'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
