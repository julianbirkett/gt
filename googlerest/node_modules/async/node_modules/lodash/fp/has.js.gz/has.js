var convert = require('./convert'),
    func = convert('has', require('../has'));

func.placeholder = require('./placeholder');
module.exports = func;
